from app.services.analyzer import analyze_content
def test_entities():
 r=analyze_content("Login from 192.168.1.10 by admin@example.com","redact")
 assert any(x["type"]=="Email" for x in r["entities"])
 assert any(x["type"]=="IPv4" for x in r["entities"])
 assert "[REDACTED_EMAIL]" in r["sanitized_content"]
def test_phishing(): assert analyze_content("suspicious email verify your account login link")["threat_type"]=="Phishing"
def test_bruteforce(): assert analyze_content("multiple failed login attempts")["threat_type"]=="Brute Force"
def test_ransomware(): assert analyze_content("ransomware encrypted files ransom note")["threat_type"]=="Ransomware"
def test_privacy(): 
 r=analyze_content("admin@example.com from 10.0.0.2","pseudonymize")
 assert r["privacy_score_after"]>=r["privacy_score_before"]
