from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from .services.analyzer import analyze_content
from .services.database import init_db, save_analysis, recent_analyses, statistics

app=FastAPI(title="SecureGenAI API",version="1.0.0")
app.add_middleware(CORSMiddleware,allow_origins=["http://localhost:5173","http://127.0.0.1:5173"],allow_credentials=True,allow_methods=["*"],allow_headers=["*"])

class AnalyzeRequest(BaseModel):
    content:str
    mode:str="pseudonymize"

@app.on_event("startup")
def startup(): init_db()

@app.get("/api/health")
def health(): return {"status":"ok","service":"SecureGenAI"}

@app.post("/api/analyze")
def analyze(req:AnalyzeRequest):
    if not req.content.strip(): raise HTTPException(400,"Content cannot be empty")
    if len(req.content)>100000: raise HTTPException(413,"Content is too large")
    r=analyze_content(req.content,req.mode); save_analysis(r); return r

@app.post("/api/scan")
def scan(req:AnalyzeRequest):
    r=analyze_content(req.content,"none")
    return {"entities":r["entities"],"privacy_score_before":r["privacy_score_before"]}

@app.post("/api/upload")
async def upload(file:UploadFile=File(...)):
    name=file.filename or ""
    if not name.lower().endswith((".txt",".log")): raise HTTPException(400,"Only .txt and .log files are supported")
    data=await file.read()
    if len(data)>2000000: raise HTTPException(413,"File exceeds 2 MB limit")
    return {"filename":name,"content":data.decode("utf-8",errors="replace")}

@app.get("/api/history")
def history(): return recent_analyses()

@app.get("/api/statistics")
def stats(): return statistics()
