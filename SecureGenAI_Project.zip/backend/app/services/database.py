import sqlite3
from pathlib import Path
DB=Path(__file__).resolve().parents[2]/"database"/"securegenai.db"
def conn():
    DB.parent.mkdir(exist_ok=True); return sqlite3.connect(DB)
def init_db():
    c=conn(); c.execute("""CREATE TABLE IF NOT EXISTS analyses(
    id INTEGER PRIMARY KEY AUTOINCREMENT, threat_type TEXT, severity TEXT, score INTEGER,
    privacy_before INTEGER, privacy_after INTEGER, sanitized_content TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)"""); c.commit(); c.close()
def save_analysis(r):
    c=conn(); c.execute("INSERT INTO analyses(threat_type,severity,score,privacy_before,privacy_after,sanitized_content) VALUES(?,?,?,?,?,?)",
    (r["threat_type"],r["severity"],r["threat_score"],r["privacy_score_before"],r["privacy_score_after"],r["sanitized_content"])); c.commit(); c.close()
def recent_analyses():
    c=conn(); rows=c.execute("SELECT id,threat_type,severity,score,privacy_before,privacy_after,created_at FROM analyses ORDER BY id DESC LIMIT 20").fetchall(); c.close()
    return [{"id":r[0],"threat_type":r[1],"severity":r[2],"score":r[3],"privacy_before":r[4],"privacy_after":r[5],"created_at":r[6]} for r in rows]
def statistics():
    c=conn(); total=c.execute("SELECT COUNT(*) FROM analyses").fetchone()[0]; critical=c.execute("SELECT COUNT(*) FROM analyses WHERE severity='Critical'").fetchone()[0]; avg=c.execute("SELECT COALESCE(AVG(privacy_after),0) FROM analyses").fetchone()[0]; c.close()
    return {"total_analyses":total,"critical_threats":critical,"sensitive_items_processed":0,"average_privacy_score":round(avg,1)}
