import re
from collections import Counter

PATTERNS=[
("Email",r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b","High"),
("IPv4",r"\b(?:\d{1,3}\.){3}\d{1,3}\b","Medium"),
("IPv6",r"\b(?:[0-9A-Fa-f]{1,4}:){2,7}[0-9A-Fa-f]{1,4}\b","Medium"),
("Phone",r"(?<!\d)(?:\+?\d[\d\s-]{8,}\d)(?!\d)","High"),
("URL",r"https?://[^\s<>\"]+","Medium"),
("JWT",r"\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b","Critical"),
("API/Secret",r"(?i)\b(?:api[_-]?key|secret|token|password|passwd)\s*[:=]\s*[^\s,;]+","Critical"),
("Unix Path",r"(?<!\w)/(?:home|var|etc|opt|tmp|usr)/[^\s]+","Medium"),
("Windows Path",r"(?i)\b[A-Z]:\\(?:Users|Windows|ProgramData|Temp)\\[^\s]+","Medium")
]
RULES={
"Ransomware":["ransomware","encrypted files","decrypt","ransom note"],
"Phishing":["phishing","suspicious email","verify your account","credential","login link"],
"Brute Force":["failed login","multiple login attempts","brute force","authentication failures"],
"Malware":["malware","trojan","payload","malicious executable","virus"],
"SQL Injection":["sql injection","union select","' or '1'='1","drop table"],
"XSS":["cross-site scripting","<script>","xss"],
"DDoS":["ddos","denial of service","traffic flood","request flood"],
"Data Exfiltration":["exfiltration","data theft","stolen data","outbound transfer"],
"Account Compromise":["account compromised","unauthorized access","credential theft"],
"Reconnaissance":["port scan","scanning","enumeration","reconnaissance"],
"Social Engineering":["social engineering","impersonation","urgent payment"]
}
RISK={"Critical":30,"High":20,"Medium":10,"Low":5}

def detect_entities(text):
    found=[]
    for typ,pat,risk in PATTERNS:
        for m in re.finditer(pat,text):
            v=m.group()
            if typ=="IPv4" and any(int(x)>255 for x in v.split(".")): continue
            found.append({"type":typ,"value":v,"risk":risk,"start":m.start(),"end":m.end()})
    found.sort(key=lambda x:x["start"])
    clean=[]; occupied=[]
    for e in found:
        if any(not(e["end"]<=a or e["start"]>=b) for a,b in occupied): continue
        clean.append(e); occupied.append((e["start"],e["end"]))
    return clean

def transform(text,entities,mode):
    if mode=="none": return text,[]
    c=Counter(); changes=[]
    for e in entities:
        c[e["type"]]+=1
        if mode=="redact": repl="[REDACTED_"+e["type"].upper().replace("/","_")+"]"
        elif mode=="mask":
            v=e["value"]; repl=v if len(v)<=4 else v[:2]+"*"*max(2,len(v)-4)+v[-2:]
        else: repl=e["type"].upper().replace("/","_")+"_%02d"%c[e["type"]]
        changes.append({"original_type":e["type"],"replacement":repl})
    for e,ch in reversed(list(zip(entities,changes))):
        text=text[:e["start"]]+ch["replacement"]+text[e["end"]:]
    return text,changes

def classify(text):
    low=text.lower(); scores={}
    for threat,words in RULES.items():
        hits=[w for w in words if w in low]
        if hits: scores[threat]=hits
    if not scores: return "Suspicious/Unknown",45,"No strong signature matched; manual review is recommended."
    threat=max(scores,key=lambda x:len(scores[x]))
    return threat,min(98,65+10*len(scores[threat])),"Indicators detected: "+", ".join(scores[threat][:5])

def privacy_score(entities):
    return max(0,100-min(100,sum(RISK[e["risk"]] for e in entities)))

def analyze_content(content,mode="pseudonymize"):
    entities=detect_entities(content)
    sanitized,changes=transform(content,entities,mode)
    threat,confidence,reason=classify(sanitized)
    score=min(100,sum(RISK[e["risk"]] for e in entities)+{"Ransomware":30,"Data Exfiltration":25,"Malware":22,"Phishing":18,"Brute Force":18}.get(threat,10))
    severity="Critical" if score>=75 else "High" if score>=50 else "Medium" if score>=25 else "Low"
    technical=f"Potential {threat} activity was identified. Severity is {severity}. The result is based on observable indicators in the submitted content."
    management=f"A potential {threat.lower()} security event was detected. The security team should validate the event and follow the organization's incident-response process."
    communication=f"Security monitoring identified a potential {threat.lower()} incident. Avoid suspicious links or credential sharing and report unusual activity to the security team."
    after=privacy_score(detect_entities(sanitized))
    return {"threat_type":threat,"confidence":confidence,"threat_score":score,"severity":severity,"reason":reason,
    "entities":[{k:e[k] for k in ("type","value","risk")} for e in entities],
    "sanitized_content":sanitized,"changes":changes,"privacy_score_before":privacy_score(entities),
    "privacy_score_after":after,"technical_summary":technical,"management_summary":management,"communication":communication}
